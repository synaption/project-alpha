# Mini Metro (Bevy)

A small Mini Metro–style game written in Rust with the [Bevy](https://bevy.org)
game engine (v0.18), structured around Bevy's ECS. Stations of different shapes
appear over time and grow queues of passengers; you draw metro lines between
them, trains run those lines automatically, and you score a point for every
passenger delivered to a station of the shape they want. If any station's queue
overflows, it's game over.

The whole thing renders with Bevy's immediate-mode **gizmos** and an embedded
default font, so the compiled binary is fully self-contained — no asset files
to ship.

## ECS structure

| File             | Role                                                            |
|------------------|-----------------------------------------------------------------|
| `components.rs`  | Per-entity data: `Shape`, `Station`, `Train`, `ScoreText`       |
| `resources.rs`   | Global state: `Game`, `Lines`, `ActiveLine`, `Drag`, `SpawnTimers`, `Rng` |
| `systems.rs`     | All logic as systems: spawning, input, train movement, rendering, HUD |
| `main.rs`        | Builds the `App`, registers resources, schedules the systems    |

## Controls

- **1 / 2 / 3** — pick which of the three coloured lines you're editing.
- **Click a station and drag to another**, then release, to connect them on the
  active line. You can only extend a line from one of its two endpoints. The
  first connection on a line spawns its train automatically.

## Run it

You need Rust (install via <https://rustup.rs>), 1.85 or newer.

```bash
cargo run            # debug; first build downloads + compiles Bevy (a few minutes)
cargo run --release  # smoother
```

> Tip: the first Bevy build is slow because it compiles the whole engine. Later
> builds are incremental and fast.

## Export a Windows .exe

### Option A — build on Windows (simplest, most reliable)

1. Install Rust from <https://rustup.rs> (the default `x86_64-pc-windows-msvc`
   toolchain). You'll also need the **MSVC build tools** — install
   "Desktop development with C++" from the Visual Studio Build Tools.
2. From the project folder:
   ```powershell
   cargo build --release
   ```
3. Your executable is at:
   ```
   target\release\mini-metro-bevy.exe
   ```
   It's self-contained — copy that single file anywhere and run it.

### Option B — cross-compile to Windows from Linux/macOS

The most reliable cross-compile path targets MSVC via
[`cargo-xwin`](https://github.com/rust-cross/cargo-xwin) (it fetches the
Windows SDK/CRT for you):

```bash
cargo install cargo-xwin
rustup target add x86_64-pc-windows-msvc
cargo xwin build --release --target x86_64-pc-windows-msvc
# -> target/x86_64-pc-windows-msvc/release/mini-metro-bevy.exe
```

Alternatively, the GNU target with mingw-w64 also works:

```bash
rustup target add x86_64-pc-windows-gnu
# Debian/Ubuntu: sudo apt install mingw-w64
# macOS:         brew install mingw-w64
cargo build --release --target x86_64-pc-windows-gnu
# -> target/x86_64-pc-windows-gnu/release/mini-metro-bevy.exe
```

## Ideas to extend it

- More shapes (star, plus) — add variants to `Shape` and a case in `draw_shape`.
- Limited line length / a finite pool of trains and "carriages".
- Smooth curved track, station rings that fill as their queue grows, sound.
- On-screen menus and a restart key (toggle `Game::phase` back to `Playing`).
